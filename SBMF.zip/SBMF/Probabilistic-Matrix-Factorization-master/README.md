Dataset: the dataset can be downloaded  on http://jmcauley.ucsd.edu/data/amazon/

Function of different file

Sentimen analysis:
input: the original jsondataset
output：a new json dataset where reviewText is replaced by its normalized sentiment score

write:
input: the json dataset with sentment score
output: a new json dataset where helpful is replaced by its normalized weight

cred:
calculate the reliability of each user

reliability:
calculate the weight of each tip of review






